<template>
  <div class="headbar-wrapper">
    <headbar-top />
  </div>
</template>
<script>
import HeadbarTop from './HeadbarTop'
export default {
  components: {
    HeadbarTop
  },
  data() {
    return {

    }
  }
}
</script>
