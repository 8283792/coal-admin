import Vue from 'vue'

const eventHub = new Vue()

export default eventHub
